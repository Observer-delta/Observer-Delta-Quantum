From https: // github.com / serge - sans - paille / numpy - benchmarks
